import debug from "debug";
import { randomUUID } from "node:crypto";
import * as fsPromises from "fs/promises";
import type { FileSystemAdapter } from "obsidian";
import { normalizePath, Notice, Platform } from "obsidian";
import * as path from "path";
import { resolve, sep } from "path";
import type * as simple from "simple-git";
import { simpleGit, GitError, CleanOptions } from "simple-git";
import {
    ASK_PASS_SCRIPT,
    ASK_PASS_SCRIPT_FILE,
    DEFAULT_WIN_GIT_PATH,
    GIT_LINE_AUTHORING_MOVEMENT_DETECTION_MINIMAL_LENGTH,
} from "src/constants";
import type { LineAuthorFollowMovement } from "src/editor/lineAuthor/model";
import { t } from "src/i18n";
import { redactCredentials } from "../redaction";
import type ObsidianGit from "../main";
import type {
    Blame,
    BlameCommit,
    BranchInfo,
    DiffFile,
    FileStatusResult,
    GitProgress,
    LogEntry,
    PullResult,
    PushResult,
    Status,
} from "../types";
import { GitConflictError, GitOperation, NoNetworkError } from "../types";
import { impossibleBranch, spawnAsync, splitRemoteBranch } from "../utils";
import { AskpassServer } from "./askpassServer";
import { GitManager } from "./gitManager";

export class SimpleGit extends GitManager {
    git!: simple.SimpleGit;
    absoluteRepoPath!: string;
    private askpassServer: AskpassServer | undefined;
    private unloaded = false;
    useDefaultWindowsGitPath: boolean = false;
    constructor(plugin: ObsidianGit) {
        super(plugin);
    }

    async setGitInstance(ignoreError = false): Promise<void> {
        if (this.unloaded) return;
        // 所有底层命名空间都禁用，避免凭据绕过插件脱敏输出。
        const namespaces = debug.disable().split(",").filter(Boolean);
        debug.enable([...namespaces, "-simple-git", "-simple-git:*"].join(","));
        this.askpassServer?.stop();
        this.askpassServer = undefined;
        const gitInstalled = await this.isGitInstalled();
        if (this.unloaded) return;
        if (gitInstalled) {
            const adapter = this.app.vault.adapter as FileSystemAdapter;
            const vaultBasePath = adapter.getBasePath();
            let basePath = vaultBasePath;
            // Because the basePath setting is a relative path, a leading `/` must
            // be appended before concatenating with the path.
            if (this.plugin.settings.basePath) {
                const exists = await adapter.exists(
                    normalizePath(this.plugin.settings.basePath)
                );
                if (exists) {
                    basePath = path.join(
                        vaultBasePath,
                        this.plugin.settings.basePath
                    );
                } else if (!ignoreError) {
                    new Notice(t("ObsidianGit: Base path does not exist"));
                }
            }
            this.absoluteRepoPath = basePath;

            const pathPaths = this.plugin.localStorage.getPATHPaths();
            const envVars = this.plugin.localStorage.getEnvVars();
            const gitDir = this.plugin.settings.gitDir;
            const envs = { ...process.env };
            if (pathPaths.length > 0) {
                const joinedPath =
                    pathPaths.join(path.delimiter) +
                    path.delimiter +
                    envs["PATH"];
                envs["PATH"] = joinedPath;
            }
            if (gitDir) {
                envs["GIT_DIR"] = gitDir;
                envs["GIT_WORK_TREE"] = basePath;
            }
            for (const envVar of envVars) {
                const [key, value] = envVar.split("=");
                if (key === undefined) continue;
                envs[key] = value;
            }

            this.git = simpleGit({
                baseDir: basePath,
                binary:
                    this.plugin.localStorage.getGitPath() ||
                    (this.useDefaultWindowsGitPath
                        ? DEFAULT_WIN_GIT_PATH
                        : undefined),
                config: ["core.quotepath=off"],
                // Preserve the inherited and user-configured environment
                allowEnvironment: [
                    ...Object.keys(envs),
                    "GIT_ASKPASS",
                    "SSH_ASKPASS",
                    "SSH_ASKPASS_REQUIRE",
                    "OBSIDIAN_GIT_ASKPASS_PORT",
                    "OBSIDIAN_GIT_ASKPASS_TOKEN",
                    "OBSIDIAN_GIT",
                ],
                progress: (progress) => {
                    this.plugin.statusBar?.displayProgress(
                        this.toGitProgress(progress)
                    );
                },
                unsafe: {
                    allowAbbreviatedOptions: true,
                    allowUnsafeCustomBinary: true,
                    allowUnsafeEditor: true,
                    allowUnsafeAskPass: true,
                    allowUnsafeConfigEnvCount: true,
                    allowUnsafeConfigPaths: true,
                    allowUnsafeCredentialHelper: true,
                    allowUnsafeGitProxy: true,
                    allowUnsafeGpgProgram: true,
                    allowUnsafeHooksPath: true,
                    allowUnsafeMergeDriver: true,
                    allowUnsafeSshCommand: true,
                    allowUnsafePager: true,
                    allowUnsafeDiffTextConv: true,
                    allowUnsafeCommandBinaries: true,
                    allowUnsafeExec: true,
                    allowUnsafeInclude: true,
                    allowUnsafeSubmodule: true,
                    allowUnsafeUrlRewrite: true,
                },
            });

            if (await this.git.env(envs).checkIsRepo()) {
                // Resolve the relative root reported by git into an absolute path
                // in case git resides in a different filesystem (eg, WSL)
                const relativeRoot = await this.git.revparse("--show-cdup");
                const absoluteRoot = resolve(basePath + sep + relativeRoot);

                this.absoluteRepoPath = absoluteRoot;
                await this.git.cwd(absoluteRoot);
            }
            if (this.unloaded) return;

            const absolutePluginConfigPath = path.join(
                vaultBasePath,
                this.app.vault.configDir,
                "plugins",
                this.plugin.manifest.id
            );
            const askPassPath = path.join(
                absolutePluginConfigPath,
                ASK_PASS_SCRIPT_FILE
            );
            // Remove any credential files left by the previous bridge.
            const legacyInput = path.join(
                absolutePluginConfigPath,
                ".git_credentials_input"
            );
            await fsPromises.rm(legacyInput, { force: true });
            await fsPromises.rm(`${legacyInput}.response`, { force: true });
            if (this.unloaded) return;

            if (envs["SSH_ASKPASS"] == undefined) {
                if (!(await this.startAskpass(askPassPath, envs))) return;
                envs["SSH_ASKPASS"] = askPassPath;
                if (envs["GIT_ASKPASS"] == undefined) {
                    envs["GIT_ASKPASS"] = askPassPath;
                }

                // OpenSSH uses the askpass program without DISPLAY when this
                // is forced, including on Windows.
                envs["SSH_ASKPASS_REQUIRE"] = "force";
            }
            if (this.unloaded) return;

            envs["OBSIDIAN_GIT"] = "1";

            this.git = this.git.env(envs);
        }
    }

    private toGitProgress(
        progress: simple.SimpleGitProgressEvent
    ): GitProgress {
        return {
            action: this.getProgressAction(progress.method),
            stage: progress.stage,
            progress: progress.progress,
            processed: progress.processed,
            total: progress.total,
        };
    }

    private getProgressAction(method: string): string {
        switch (method) {
            case "fetch":
                return "Fetching";
            case "push":
                return "Pushing";
            case "pull":
                return "Pulling";
            case "checkout":
                return "Checking out";
            default:
                return method
                    ? method.charAt(0).toUpperCase() + method.slice(1)
                    : "Working";
        }
    }

    // Constructs a path relative to the vault from a path relative to the git repository
    getRelativeVaultPath(filePath: string): string {
        const adapter = this.app.vault.adapter as FileSystemAdapter;
        const from = adapter.getBasePath();

        const to = path.join(this.absoluteRepoPath, filePath);

        let res = path.relative(from, to);
        if (Platform.isWin) {
            res = res.replace(/\\/g, "/");
        }
        return res;
    }

    // Constructs a path relative to the git repository from a path relative to the vault
    //
    // @param doConversion - If false, the path is returned as is. This is added because that parameter is often passed on to functions where this method is called.
    getRelativeRepoPath(
        filePath: string,
        doConversion: boolean = true
    ): string {
        if (doConversion) {
            const adapter = this.plugin.app.vault.adapter as FileSystemAdapter;
            const vaultPath = adapter.getBasePath();
            const from = this.absoluteRepoPath;
            const to = path.join(vaultPath, filePath);
            let res = path.relative(from, to);
            if (Platform.isWin) {
                res = res.replace(/\\/g, "/");
            }
            return res;
        }
        return filePath;
    }

    protected getVaultPathspec(): string | undefined {
        if (!this.plugin.settings.limitToVault) return undefined;

        const adapter = this.app.vault.adapter as FileSystemAdapter;
        const vaultPath = path.resolve(adapter.getBasePath());
        const repositoryPath = path.resolve(this.absoluteRepoPath);
        const relativePath = path.relative(repositoryPath, vaultPath);

        if (
            relativePath === "" ||
            relativePath === ".." ||
            relativePath.startsWith(".." + path.sep) ||
            path.isAbsolute(relativePath)
        ) {
            return undefined;
        }

        return relativePath.split(path.sep).join("/");
    }

    private async countPathsOutsideVault(args: string[]): Promise<number> {
        const output = await this.git.raw([...args, "-z"]);
        return output
            .split("\0")
            .filter((filePath) => filePath && !this.isPathInsideVault(filePath))
            .length;
    }

    private get relPluginConfigPath(): string {
        return path.join(
            this.app.vault.configDir,
            "plugins",
            this.plugin.manifest.id
        );
    }

    private async startAskpass(
        askPassPath: string,
        envs: NodeJS.ProcessEnv
    ): Promise<boolean> {
        await this.addAskPassScriptToExclude();
        if (this.unloaded) return false;
        await fsPromises.writeFile(askPassPath, ASK_PASS_SCRIPT);
        await fsPromises.chmod(askPassPath, 0o755);
        if (this.unloaded) return false;

        const server = new AskpassServer(this.plugin);
        this.askpassServer?.stop();
        this.askpassServer = server;
        let port: number;
        let token: string;
        try {
            ({ port, token } = await server.start());
        } catch (error) {
            if (this.unloaded || this.askpassServer !== server) return false;
            throw error;
        }
        if (this.unloaded || this.askpassServer !== server) {
            server.stop();
            return false;
        }
        envs["OBSIDIAN_GIT_ASKPASS_PORT"] = `${port}`;
        envs["OBSIDIAN_GIT_ASKPASS_TOKEN"] = token;
        return true;
    }

    /**
     * Adds the askpass script to the exclude file of the git repository.
     *
     * This prevents the script from being tracked by git. This should be no
     * problem as the script does not contain any sensitive data, but may
     * cause issues with file permissions on other devices.
     * See https://github.com/Vinzent03/obsidian-git/issues/903
     */
    async addAskPassScriptToExclude(): Promise<void> {
        try {
            if (!(await this.git.checkIsRepo())) {
                return;
            }
            const absoluteExcludeFilePath = await this.git.revparse([
                "--path-format=absolute",
                "--git-path",
                "info/exclude",
            ]);

            const vaultRelativeAskPassScriptFile = path.join(
                this.app.vault.configDir,
                "plugins",
                this.plugin.manifest.id,
                ASK_PASS_SCRIPT_FILE
            );
            const repoRelativeAskPassScriptFile = this.getRelativeRepoPath(
                vaultRelativeAskPassScriptFile,
                true
            );

            const content = await fsPromises.readFile(
                absoluteExcludeFilePath,
                "utf-8"
            );
            const lines = content.split("\n");
            const contains = lines.some((line) =>
                line.includes(repoRelativeAskPassScriptFile)
            );
            if (!contains) {
                await fsPromises.appendFile(
                    absoluteExcludeFilePath,
                    repoRelativeAskPassScriptFile + "\n"
                );
            }
        } catch (error) {
            // Catch any errors, because this is not critical
            console.error(
                "Error while adding askpass script to exclude file:",
                error
            );
        }
    }

    unload(): void {
        this.unloaded = true;
        this.askpassServer?.stop();
        this.askpassServer = undefined;
    }

    async status(opts?: { path?: string }): Promise<Status> {
        const dir = opts?.path ?? this.getVaultPathspec();
        const [status, stagedOutsideVault, conflictedOutsideVault] =
            await Promise.all([
                this.git.status(dir != undefined ? ["--", dir] : []),
                this.getVaultPathspec() == undefined
                    ? 0
                    : this.countPathsOutsideVault([
                          "diff",
                          "--cached",
                          "--name-only",
                          "--diff-filter=ACDMRT",
                      ]),
                this.getVaultPathspec() == undefined
                    ? 0
                    : this.countPathsOutsideVault([
                          "diff",
                          "--name-only",
                          "--diff-filter=U",
                      ]),
            ]);

        const allFilesFormatted = status.files.map<FileStatusResult>((e) => {
            const res = this.formatPath(e);
            return {
                path: res.path,
                from: res.from,
                index: e.index === "?" ? "U" : e.index,
                workingDir: e.working_dir === "?" ? "U" : e.working_dir,
                vaultPath: this.getRelativeVaultPath(res.path),
            };
        });
        const conflicted = status.conflicted.map(
            (path) => this.formatPath({ path }).path
        );
        const conflictedPaths = new Set(conflicted);
        return {
            all: allFilesFormatted,
            changed: allFilesFormatted.filter(
                (e) => e.workingDir !== " " && !conflictedPaths.has(e.path)
            ),
            staged: allFilesFormatted.filter(
                (e) => e.index !== " " && e.index != "U"
            ),
            ahead: status.ahead ?? 0,
            behind: status.behind ?? 0,
            conflicted,
            stagedOutsideVault,
            conflictedOutsideVault,
        };
    }

    async isMergeInProgress(): Promise<boolean> {
        const mergeHead = await this.git.revparse(["--git-path", "MERGE_HEAD"]);
        const mergeHeadPath = path.resolve(
            this.absoluteRepoPath,
            mergeHead.trim()
        );
        try {
            await fsPromises.access(mergeHeadPath);
            return true;
        } catch (error) {
            if (
                error instanceof Error &&
                "code" in error &&
                error.code === "ENOENT"
            ) {
                return false;
            }
            throw error;
        }
    }

    async submoduleAwareHeadRevisonInContainingDirectory(
        filepath: string
    ): Promise<string> {
        const repoPath = this.getRelativeRepoPath(filepath);

        const containingDirectory = path.dirname(repoPath);
        const args = ["-C", containingDirectory, "rev-parse", "HEAD"];

        const result = this.git.raw(args);
        result.catch((err) =>
            console.warn("obsidian-git: rev-parse error:", err)
        );
        return (await result).trim();
    }

    async getSubmodulePaths(): Promise<string[]> {
        return new Promise<string[]>((resolve) => {
            this.git.outputHandler((_cmd, stdout, _stderr, args) => {
                // Do not run this handler on other commands
                if (!(args.contains("submodule") && args.contains("foreach"))) {
                    return;
                }

                let body = "";
                // `submodule foreach` prints paths relative to git's cwd, which
                // is the repo root (see setGitInstance), not the vault folder.
                // The vault may live in a subfolder of the repo, in which case
                // prefixing the vault path yields a non-existent directory.
                const root = this.absoluteRepoPath;
                stdout.on("data", (chunk: Buffer) => {
                    body += chunk.toString("utf8");
                });
                stdout.on("end", () => {
                    const submods = body.split("\n");

                    // Remove words like `Entering` in front of each line and filter empty lines
                    const strippedSubmods: string[] = submods
                        .map((i) => {
                            const submod = i.match(/'([^']*)'/);
                            if (submod != undefined) {
                                return root + "/" + submod[1]! + sep;
                            }
                            return undefined;
                        })
                        .filter((i): i is string => !!i)
                        .filter((submodulePath) => {
                            if (this.getVaultPathspec() == undefined) {
                                return true;
                            }
                            const adapter = this.app.vault
                                .adapter as FileSystemAdapter;
                            const relativePath = path.relative(
                                path.resolve(adapter.getBasePath()),
                                path.resolve(submodulePath)
                            );
                            return !(
                                relativePath === ".." ||
                                relativePath.startsWith(".." + path.sep) ||
                                path.isAbsolute(relativePath)
                            );
                        });

                    strippedSubmods.reverse();
                    resolve(strippedSubmods);
                });
            });

            this.git.subModule(["foreach", "--recursive", ""]).then(
                () => {
                    this.git.outputHandler(() => {});
                },
                (e) => this.plugin.displayError(e)
            );
        });
    }

    //Remove wrong `"` like "My file.md"
    formatPath(path: { from?: string; path: string }): {
        path: string;
        from?: string;
    } {
        function format(path?: string): string | undefined {
            if (path == undefined) return undefined;

            if (path.startsWith('"') && path.endsWith('"')) {
                return path.substring(1, path.length - 1);
            } else {
                return path;
            }
        }
        if (path.from != undefined) {
            return {
                from: format(path.from),
                path: format(path.path)!,
            };
        } else {
            return {
                path: format(path.path)!,
            };
        }
    }

    async blame(
        path: string,
        trackMovement: LineAuthorFollowMovement,
        ignoreWhitespace: boolean
    ): Promise<Blame | "untracked"> {
        path = this.getRelativeRepoPath(path);

        if (!(await this.isTracked(path))) return "untracked";

        const inSubmodule = await this.getSubmoduleOfFile(path);
        const args = inSubmodule ? ["-C", inSubmodule.submodule] : [];
        const relativePath = inSubmodule ? inSubmodule.relativeFilepath : path;

        args.push("blame", "--porcelain");

        if (ignoreWhitespace) args.push("-w");

        const trackCArg = `-C${GIT_LINE_AUTHORING_MOVEMENT_DETECTION_MINIMAL_LENGTH}`;
        switch (trackMovement) {
            case "inactive":
                break;
            case "same-commit":
                args.push("-C", trackCArg);
                break;
            case "all-commits":
                args.push("-C", "-C", trackCArg);
                break;
            default:
                impossibleBranch(trackMovement);
        }

        args.push("--", relativePath);

        const rawBlame = await this.git.raw(args);
        return parseBlame(rawBlame);
    }

    async isTracked(path: string): Promise<boolean> {
        const inSubmodule = await this.getSubmoduleOfFile(path);
        const args = inSubmodule ? ["-C", inSubmodule.submodule] : [];
        const relativePath = inSubmodule ? inSubmodule.relativeFilepath : path;

        args.push("ls-files", "--", relativePath);
        return this.git.raw(args).then((x) => x.trim() !== "");
    }

    async commitAll({
        message,
        allowEmpty,
        amend,
        protective,
    }: {
        message: string;
        allowEmpty?: boolean;
        amend?: boolean;
        protective?: boolean;
    }): Promise<number> {
        return this.withGitOperation(GitOperation.commit, async () => {
            if (protective || this.plugin.settings.updateSubmodules) {
                await this.assertSafeSyncScope();
            }
            const vaultPath = this.getVaultPathspec();
            await this.git.add(
                vaultPath == undefined ? "-A" : ["-A", "--", vaultPath]
            );

            const res = await this.git.commit(
                await this.formatCommitMessage(message),
                [
                    ...(allowEmpty ? ["--allow-empty"] : []),
                    ...(amend ? ["--amend"] : []),
                ]
            );
            this.app.workspace.trigger("obsidian-git:head-change");
            return this.getCommittedFilesCount(res.summary.changes);
        }).catch((error: unknown) => this.throwConflictError(error));
    }

    async commit({
        message,
        amend,
    }: {
        message: string;
        amend?: boolean;
    }): Promise<number> {
        return this.withGitOperation(GitOperation.commit, async () => {
            try {
                const res = await this.git.commit(
                    await this.formatCommitMessage(message),
                    amend ? ["--amend"] : []
                );
                this.app.workspace.trigger("obsidian-git:head-change");
                return this.getCommittedFilesCount(res.summary.changes);
            } catch (error) {
                return this.throwConflictError(error);
            }
        });
    }

    private async getCommittedFilesCount(
        summaryChanges: number
    ): Promise<number> {
        if (summaryChanges !== 0) return summaryChanges;
        // In case of a merge commit, the summary emitted by the commit command is empty.

        const parents = await this.git.raw([
            "rev-list",
            "--parents",
            "-1",
            "HEAD",
        ]);
        if (parents.trim().split(/\s+/).length === 1) return 0;
        return (await this.git.diffSummary(["HEAD^1", "HEAD"])).changed;
    }

    async stage(path: string, relativeToVault: boolean): Promise<void> {
        path = this.getRelativeRepoPath(path, relativeToVault);
        await this.git.add(["--", path]);
    }

    async stageAll({ dir }: { dir?: string }): Promise<void> {
        const scopedDir = dir ?? this.getVaultPathspec();
        await this.git.add(
            scopedDir == undefined ? "-A" : ["-A", "--", scopedDir]
        );
    }

    async unstageAll({ dir }: { dir?: string }): Promise<void> {
        const scopedDir = dir ?? this.getVaultPathspec();
        await this.git.reset(scopedDir != undefined ? ["--", scopedDir] : []);
    }

    async unstage(path: string, relativeToVault: boolean): Promise<void> {
        path = this.getRelativeRepoPath(path, relativeToVault);
        await this.git.reset(["--", path]);
    }

    async discard(filepath: string): Promise<void> {
        if (await this.isTracked(filepath)) {
            await this.git.checkout(["--progress", "--", filepath]);
        }
    }

    async applyPatch(patch: string): Promise<void> {
        const patchPath = path.join(this.relPluginConfigPath, "patch");
        await this.app.vault.adapter.write(patchPath, patch);
        await this.git.applyPatch(patchPath, {
            "--cached": null,
            "--unidiff-zero": null,
            "--whitespace": "nowarn",
        });
        await this.app.vault.adapter.remove(patchPath);
    }

    async getUntrackedPaths(opts: { path?: string }): Promise<string[]> {
        const dir = opts?.path ?? this.getVaultPathspec();
        const args = [];
        if (dir != undefined) {
            args.push("--", dir);
        }
        const untrackedFiles = await this.git.clean(
            CleanOptions.RECURSIVE + CleanOptions.DRY_RUN,
            args
        );

        return untrackedFiles.paths;
    }

    async hashObject(filepath: string): Promise<string> {
        // Need to use raw command here to ensure filenames are literally used.
        // Perhaps we could file a PR? https://github.com/steveukx/git-js/blob/main/simple-git/src/lib/tasks/hash-object.ts
        filepath = this.getRelativeRepoPath(filepath);
        const inSubmodule = await this.getSubmoduleOfFile(filepath);
        const args = inSubmodule ? ["-C", inSubmodule.submodule] : [];
        const relativeFilepath = inSubmodule
            ? inSubmodule.relativeFilepath
            : filepath;

        args.push("hash-object", "--", relativeFilepath);

        const revision = this.git.raw(args);
        return revision;
    }

    async discardAll({ dir }: { dir?: string }): Promise<void> {
        return this.discard(dir ?? this.getVaultPathspec() ?? ".");
    }

    private async gitStatePath(name: string): Promise<string> {
        return path.resolve(
            this.absoluteRepoPath,
            (await this.git.revparse(["--git-path", name])).trim()
        );
    }

    private async assertNoSubmodules(): Promise<void> {
        const entries = await this.git.raw(["ls-files", "--stage", "-z"]);
        if (
            this.plugin.settings.updateSubmodules ||
            entries.split("\0").some((entry) => entry.startsWith("160000 "))
        ) {
            throw this.safetyError("sync/submodule");
        }
    }

    private async assertNoSubmoduleTree(ref: string): Promise<void> {
        const entries = await this.git.raw(["ls-tree", "-r", "-z", ref]);
        if (entries.split("\0").some((entry) => entry.startsWith("160000 "))) {
            throw this.safetyError("sync/submodule");
        }
    }

    private async assertSafeSyncScope(): Promise<void> {
        await this.assertNoSubmodules();
        if (this.getVaultPathspec() != undefined) {
            const status = await this.git.status();
            if (
                status.files.some(
                    (file) =>
                        !this.isPathInsideVault(this.formatPath(file).path)
                )
            ) {
                throw this.safetyError("sync/outside-vault");
            }
        }
    }

    private async assertSafePush(): Promise<void> {
        await this.assertNoSubmodules();
        const config = await this.git.raw(["config", "--null", "--list"]);
        for (const entry of config.split("\0")) {
            const separator = entry.indexOf("\n");
            const key = (
                separator < 0 ? entry : entry.slice(0, separator)
            ).toLowerCase();
            const value = separator < 0 ? "" : entry.slice(separator + 1);
            if (
                /^remote\..+\.mirror$/.test(key) &&
                !["false", "no", "off", "0"].includes(value.toLowerCase())
            ) {
                throw this.safetyError("push/mirror");
            }
            if (/^remote\..+\.push$/.test(key)) {
                const [source, destination, ...extra] = value.split(":");
                if (
                    !source ||
                    source.startsWith("+") ||
                    value.includes("*") ||
                    extra.length > 0 ||
                    destination === "" ||
                    (destination != undefined && destination.startsWith("-"))
                ) {
                    throw this.safetyError("push/refspec");
                }
            }
        }
    }

    async pull(): Promise<PullResult> {
        return this.withGitOperation(GitOperation.pull, async () => {
            try {
                await this.assertSafeSyncScope();

                const branchInfo = await this.branchInfo();
                if (!branchInfo.current) {
                    throw new Error(t("No current branch found. Cannot pull."));
                }
                const localCommit = await this.git.revparse([
                    branchInfo.current,
                ]);
                await this.assertNoSubmoduleTree(localCommit.trim());

                if (!branchInfo.tracking) {
                    if (this.plugin.settings.updateSubmodules) {
                        this.plugin.log(
                            t(
                                "No tracking branch found. Ignoring pull of main repo and updating submodules only."
                            )
                        );
                    }
                    return { status: "skipped", reason: "no-upstream" };
                }

                await this.git.fetch();
                const upstreamCommit = await this.git.revparse([
                    branchInfo.tracking,
                ]);
                await this.assertNoSubmoduleTree(upstreamCommit.trim());

                if (localCommit !== upstreamCommit) {
                    if (
                        this.plugin.settings.syncMethod === "merge" ||
                        this.plugin.settings.syncMethod === "rebase"
                    ) {
                        try {
                            const args = [branchInfo.tracking];

                            if (this.plugin.settings.mergeStrategy !== "none") {
                                args.push(
                                    `--strategy-option=${this.plugin.settings.mergeStrategy}`
                                );
                            }

                            switch (this.plugin.settings.syncMethod) {
                                case "merge":
                                    await this.git.merge(args);
                                    break;
                                case "rebase": {
                                    if (
                                        this.plugin.settings.rebaseAutoStash ===
                                        "enabled"
                                    ) {
                                        args.push("--autostash");
                                    } else if (
                                        this.plugin.settings.rebaseAutoStash ===
                                        "disabled"
                                    ) {
                                        args.push("--no-autostash");
                                    }
                                    await this.git.rebase(args);
                                    break;
                                }
                            }
                        } catch (error) {
                            await this.throwConflictError(error);
                        }
                    } else if (this.plugin.settings.syncMethod === "reset") {
                        // 独立引用保留旧历史；--keep 在覆盖本地改动前拒绝执行。
                        await this.git.raw([
                            "update-ref",
                            `refs/obsidian-git/pre-reset/${localCommit.trim()}`,
                            localCommit.trim(),
                        ]);
                        await this.git.reset(["--keep", upstreamCommit]);
                    }
                    const afterMergeCommit = await this.git.revparse([
                        branchInfo.current,
                    ]);

                    if (afterMergeCommit === localCommit) {
                        return { status: "up-to-date" };
                    }

                    this.app.workspace.trigger("obsidian-git:head-change");

                    const filesChanged = await this.git.diff([
                        `${localCommit}..${afterMergeCommit}`,
                        "--name-only",
                    ]);

                    const changedPaths = filesChanged
                        .split(/\r\n|\r|\n/)
                        .filter((value) => value.length > 0);
                    const vaultFiles = changedPaths.filter((filePath) =>
                        this.isPathInsideVault(filePath)
                    );
                    return {
                        status: "updated",
                        outsideVault: changedPaths.length - vaultFiles.length,
                        files: vaultFiles.map((filePath) => ({
                            path: filePath,
                            workingDir: "P",
                            index: "P",
                            vaultPath: this.getRelativeVaultPath(filePath),
                        })),
                    };
                } else {
                    return { status: "up-to-date" };
                }
            } catch (e) {
                this.convertErrors(e);
            }
        });
    }

    /**
     * 中止当前进行中的合并或变基，恢复到冲突前状态。
     * 同步前的保护性提交（若存在）仍留在历史中，可完整回滚。
     */
    async abortMergeOrRebase(): Promise<void> {
        const statePath = async (name: string) =>
            path.resolve(
                this.absoluteRepoPath,
                (await this.git.revparse(["--git-path", name])).trim()
            );
        if (await this.exists(await statePath("MERGE_HEAD"))) {
            await this.git.raw(["merge", "--abort"]);
        } else if (
            (await this.exists(await statePath("rebase-merge"))) ||
            (await this.exists(await statePath("rebase-apply")))
        ) {
            await this.git.raw(["rebase", "--abort"]);
        } else {
            throw new Error(t("No merge or rebase in progress"));
        }
        this.plugin.setPluginState({ mergeInProgress: false });
        this.app.workspace.trigger("obsidian-git:head-change");
    }

    private async exists(filepath: string): Promise<boolean> {
        try {
            await fsPromises.access(filepath);
            return true;
        } catch {
            return false;
        }
    }

    private async throwConflictError(error: unknown): Promise<never> {
        try {
            const status = await this.git.status();
            if (status.conflicted.length > 0) {
                throw new GitConflictError(
                    status.conflicted,
                    this.redactError(error)
                );
            }
        } catch (statusError) {
            if (statusError instanceof GitConflictError) {
                throw statusError;
            }
        }
        this.convertErrors(error);
    }

    async push(): Promise<PushResult> {
        return this.withGitOperation(GitOperation.push, async () => {
            try {
                await this.assertSafePush();
                const currentBranch = await this.getCurrentBranch();

                if (!currentBranch) {
                    return { status: "blocked", reason: "no-branch" };
                }

                const pushTarget = await this.getPushTarget(currentBranch);

                if (!pushTarget && this.plugin.settings.updateSubmodules) {
                    this.plugin.log(
                        "No push target found. Ignoring push of main repo and updating submodules only."
                    );
                    return { status: "skipped", reason: "no-upstream" };
                }
                let remoteChangedFiles: number | null = null;
                if (pushTarget?.exists) {
                    remoteChangedFiles = (
                        await this.git.diffSummary([
                            currentBranch,
                            pushTarget.ref,
                            "--",
                        ])
                    ).changed;
                }

                await this.git.push([
                    "--no-force",
                    "--no-mirror",
                    "--recurse-submodules=no",
                ]);

                return remoteChangedFiles === 0
                    ? { status: "up-to-date" }
                    : { status: "pushed", files: remoteChangedFiles };
            } catch (e) {
                this.convertErrors(e);
            }
        });
    }

    /**
     * Returns the remote-tracking ref that represents where an argument-less
     * `git push` sends the current branch. Unlike the upstream ref, this takes
     * push.default, branch.<name>.pushRemote and remote.pushDefault into
     * account. The ref can be configured even when the remote branch has not
     * been created yet.
     */
    private async getPushTarget(
        currentBranch: string
    ): Promise<{ ref: string; exists: boolean } | undefined> {
        const ref = (
            await this.git.raw([
                "for-each-ref",
                "--format=%(push)",
                `refs/heads/${currentBranch}`,
            ])
        ).trim();
        if (!ref) {
            return undefined;
        }

        const existingRef = (
            await this.git.raw(["for-each-ref", "--format=%(refname)", ref])
        ).trim();
        return { ref, exists: existingRef === ref };
    }

    /**
     * Squashes all local commits that have not been pushed yet into a single
     * commit. Only unpushed history is rewritten (HEAD is soft-reset onto the
     * push target), so this never requires a force-push and is safe across
     * multiple devices. The squash commit reuses the message of the most recent
     * unpushed commit, so a custom, modal or script-derived commit message is
     * preserved instead of being overwritten by the auto-commit template.
     * No-op if there is no push target, the push target does not exist yet,
     * there are fewer than two unpushed commits, a merge commit is present in
     * the unpushed range, or there are staged but uncommitted changes.
     */
    async squashAllUnpushedCommits(): Promise<void> {
        await this.assertSafePush();
        const status = await this.git.status();
        if (
            !status.current ||
            status.conflicted.length > 0 ||
            (await this.isMergeInProgress()) ||
            (await this.exists(await this.gitStatePath("rebase-merge"))) ||
            (await this.exists(await this.gitStatePath("rebase-apply")))
        ) {
            return;
        }
        // There is no safe remote base to reset onto before the push target has
        // been created, or when Git cannot determine an argument-less push
        // destination. Let the normal push publish the existing history.
        const pushTarget = await this.getPushTarget(status.current);
        if (!pushTarget?.exists) {
            return;
        }
        // A soft reset keeps the index, so any staged but uncommitted changes
        // would be folded into the squash commit, silently committing work the
        // user did not intend to. Abort the squash and let the push proceed
        // with the existing history untouched.
        const staged = (
            await this.git.raw(["diff", "--cached", "--name-only"])
        ).trim();
        if (staged.length > 0) {
            return;
        }
        const oldHead = (await this.git.revparse(["HEAD"])).trim();
        const base = (await this.git.revparse([pushTarget.ref])).trim();
        // 远端分叉或领先时不改写，避免把远端内容覆盖进新提交。
        if (
            (await this.git.raw(["merge-base", base, oldHead])).trim() !== base
        ) {
            return;
        }
        const range = `${base}..${oldHead}`;
        const unpushed = parseInt(
            (await this.git.raw(["rev-list", "--count", range])).trim(),
            10
        );
        if (unpushed < 2) {
            return;
        }
        // Flattening a merge commit would lose its structure, so skip those.
        const merges = parseInt(
            (
                await this.git.raw(["rev-list", "--merges", "--count", range])
            ).trim(),
            10
        );
        if (merges > 0) {
            return;
        }
        // Capture the current tip before rewriting so the squash commit can
        // reuse its message (commit -C) rather than the auto-commit template.
        await this.withGitOperation(GitOperation.commit, async () => {
            const id = randomUUID();
            const backupRef = `refs/obsidian-git/pre-squash/${id}`;
            const indexPath = await this.gitStatePath("index");
            const index = await fsPromises.readFile(indexPath);
            const backupPath = await this.gitStatePath(
                `obsidian-git/${id}.index`
            );
            await fsPromises.mkdir(path.dirname(backupPath), {
                recursive: true,
            });
            await fsPromises.writeFile(backupPath, index, {
                flag: "wx",
                mode: 0o600,
            });
            await this.git.raw(["update-ref", backupRef, oldHead]);
            try {
                await this.git.reset(["--soft", base]);
                await this.git.raw(["commit", "-C", oldHead]);
            } catch (error) {
                // 恢复引用和原始 index，工作区及 hook 产生的文件改动保留。
                await this.git.raw(["update-ref", "HEAD", oldHead]);
                const lockPath = `${indexPath}.lock`;
                await fsPromises.writeFile(lockPath, index, {
                    flag: "wx",
                    mode: 0o600,
                });
                await fsPromises.rename(lockPath, indexPath);
                this.convertErrors(error);
            }
            this.app.workspace.trigger("obsidian-git:head-change");
        });
    }

    async getUnpushedCommits(): Promise<number> {
        const currentBranch = await this.getCurrentBranch();

        if (currentBranch == null) {
            return 0;
        }

        const pushTarget = await this.getPushTarget(currentBranch);
        if (!pushTarget) {
            return 0;
        }
        if (!pushTarget.exists) {
            this.plugin.log(
                `Push target ${pushTarget.ref} does not exist on the remote yet.`
            );
            return 0;
        }

        const remoteChangedFiles = (
            await this.git.diffSummary([currentBranch, pushTarget.ref, "--"])
        ).changed;

        return remoteChangedFiles;
    }

    async canPush(): Promise<boolean> {
        // allow pushing in submodules even if the root has no changes.
        if (this.plugin.settings.updateSubmodules === true) {
            return true;
        }
        const currentBranch = await this.getCurrentBranch();
        if (!currentBranch) {
            this.plugin.log("During canPush check, no current branch found.");
            return false;
        }

        const pushTarget = await this.getPushTarget(currentBranch);
        if (!pushTarget) {
            return false;
        }
        if (!pushTarget.exists) {
            return true;
        }

        const [currentCommit, pushedCommit] = await Promise.all([
            this.git.revparse([currentBranch]),
            this.git.revparse([pushTarget.ref]),
        ]);

        return currentCommit !== pushedCommit;
    }

    async checkRequirements(): Promise<
        "valid" | "missing-repo" | "missing-git"
    > {
        if (!(await this.isGitInstalled())) {
            return "missing-git";
        }
        if (!(await this.git.checkIsRepo())) {
            return "missing-repo";
        }
        return "valid";
    }

    /**
     * Returns the checked out branch, or undefined if HEAD is detached. Unlike
     * `git status`, this doesn't scan the working tree.
     */
    private async getCurrentBranch(): Promise<string | undefined> {
        const branch = await this.git.raw([
            "symbolic-ref",
            "--quiet",
            "--short",
            "HEAD",
        ]);
        return branch.trim() || undefined;
    }

    async branchInfo(): Promise<BranchInfo> {
        const [current, refs] = await Promise.all([
            this.getCurrentBranch(),
            this.git.raw([
                "branch",
                "--list",
                "--no-color",
                "--format=%(refname)%00%(upstream:short)",
            ]),
        ]);

        let tracking: string | undefined;
        const branches: string[] = [];
        for (const line of refs.split("\n")) {
            const [ref, upstream] = line.split("\0");
            if (!ref?.startsWith("refs/heads/")) continue;
            const branch = ref.slice("refs/heads/".length);
            branches.push(branch);
            if (branch === current) {
                tracking = upstream || undefined;
            }
        }

        return { current, tracking, branches };
    }

    async getRemoteUrl(remote: string): Promise<string | undefined> {
        try {
            return (await this.git.remote(["get-url", remote])) || undefined;
        } catch (error) {
            // Verify the error is at least not about git is not found or similar. Checks if the remote exists or not
            if (String(error).contains(remote)) {
                return undefined;
            } else {
                throw error;
            }
        }
    }

    // https://github.com/kometenstaub/obsidian-version-history-diff/issues/3
    async log(
        file: string | undefined,
        relativeToVault = true,
        limit?: number,
        ref?: string
    ): Promise<(LogEntry & { fileName?: string })[]> {
        let path: string | undefined;
        if (file) {
            path = this.getRelativeRepoPath(file, relativeToVault);
        }
        const opts: Record<string, unknown> = {
            file: path,
            maxCount: limit,
            // Ensures that the changed files are listed for merge commits as well and the commit is not repeated for each parent.
            // This only lists the changed files for the first parent.
            "--diff-merges": "first-parent",
            "--name-status": null,
        };
        if (ref) {
            opts[ref] = null;
        }
        const res = await this.git.log(opts);

        return res.all.map<LogEntry>((e) => ({
            ...e,
            author: {
                name: e.author_name,
                email: e.author_email,
            },
            refs: e.refs.split(", ").filter((e) => e.length > 0),
            diff: {
                ...e.diff!,
                files:
                    e.diff?.files.map<DiffFile>((f) => {
                        const from = "from" in f ? f.from : undefined;
                        return {
                            ...f,
                            status: "status" in f ? f.status! : "M",
                            path: f.file,
                            hash: e.hash,
                            vaultPath: this.getRelativeVaultPath(f.file),
                            fromPath: from,
                            fromVaultPath:
                                from != undefined
                                    ? this.getRelativeVaultPath(from)
                                    : undefined,
                            binary: f.binary,
                        };
                    }) ?? [],
            },
            fileName: e.diff?.files.first()?.file,
        }));
    }

    async show(
        commitHash: string,
        file: string,
        relativeToVault = true
    ): Promise<string> {
        const path = this.getRelativeRepoPath(file, relativeToVault);

        // `--textconv` applies a configured diff.*.textconv filter (e.g.
        // git-crypt, git-secret), matching what `git diff` shows.
        return this.git.show(["--textconv", commitHash + ":" + path]);
    }

    private async getLocalBranchUpstream(
        localBranchName: string
    ): Promise<string | undefined> {
        // Returns the configured upstream ref for a local branch (e.g. `origin/main`), using
        // Return undefined when no upstream exists or if git throws an error.
        try {
            const upstream = await this.git.raw([
                "rev-parse",
                "--abbrev-ref",
                `${localBranchName}@{upstream}`,
            ]);
            const trimmed = upstream.trim();
            return trimmed.length > 0 ? trimmed : undefined;
        } catch {
            return undefined;
        }
    }

    private getAvailableLocalBranchName(
        remoteBranchName: string,
        remote: string,
        existingBranchNames: string[]
    ): string {
        // Chooses a local branch name that does not collide with `existingBranchNames`.
        // Prefers `remoteBranchName`, then `<remoteBranchName>-<remote>`, then that base with `-1`, `-2`, …
        //
        // Ex.: for a remote branch `origin/my-branch`
        // - `my-branch` is preferred
        // - `my-branch-origin` is next
        // - `my-branch-origin-1` is next
        // - `my-branch-origin-2` is next
        // - etc.

        const preferred = remoteBranchName;
        if (!existingBranchNames.includes(preferred)) {
            return preferred;
        }
        const base = `${remoteBranchName}-${remote}`;
        let candidate = base;
        let n = 0;
        while (existingBranchNames.includes(candidate)) {
            n += 1;
            candidate = `${base}-${n}`;
        }
        return candidate;
    }

    async checkout(branch: string, remote?: string): Promise<void> {
        return this.withGitOperation(GitOperation.checkout, async () => {
            if (remote) {
                // If we're trying to checkout a remote branch we'll either switch to an existing local branch that
                // already tracks it, or create a new local branch from the remote tip (name may be disambiguated).
                const remoteBranch = `${remote}/${branch}`;
                const branchInfo = await this.branchInfo();
                const localBranchExists = branchInfo.branches.includes(branch);

                // We found a local branch with the "correct" name, but it might track
                // a different remote, so we'll double check before proceeding.
                const existingBranchTracksRemote =
                    localBranchExists &&
                    (await this.getLocalBranchUpstream(branch)) ===
                        remoteBranch;

                if (existingBranchTracksRemote) {
                    // The local branch already exists AND it tracked the correct remote, so we can simply switch to it.
                    await this.git.checkout(branch);
                } else {
                    // The local branch doesn't exist or it tracks a different remote, so we'll need to create a new local branch.
                    // First we need to find a suitable name for the new local branch.
                    const localBranchName = this.getAvailableLocalBranchName(
                        branch,
                        remote,
                        branchInfo.branches
                    );

                    // Finally, we can use `git checkout -b` to create the new local branch and set it to track the remote branch.
                    await this.git.checkout([
                        "-b",
                        localBranchName,
                        remoteBranch,
                    ]);
                }
            } else {
                // Checkout an existing local branch (no remote specified).
                await this.git.checkout(branch);
            }

            if (this.plugin.settings.submoduleRecurseCheckout) {
                const submodulePaths = await this.getSubmodulePaths();
                for (const submodulePath of submodulePaths) {
                    const branchSummary = await this.git
                        .cwd({ path: submodulePath, root: false })
                        .branch();
                    if (Object.keys(branchSummary.branches).includes(branch)) {
                        await this.git
                            .cwd({ path: submodulePath, root: false })
                            .checkout(branch);
                    }
                }
            }
        });
    }

    async createBranch(branch: string): Promise<void> {
        await this.git.checkout(["-b", branch]);
    }

    async deleteBranch(branch: string, force: boolean): Promise<void> {
        await this.git.branch([force ? "-D" : "-d", branch]);
    }

    async branchIsMerged(branch: string): Promise<boolean> {
        const notMergedBranches = await this.git.branch(["--no-merged"]);
        return !notMergedBranches.all.contains(branch);
    }

    async init(): Promise<void> {
        await this.git.init(false);
    }

    async clone(url: string, dir: string, depth?: number): Promise<void> {
        await this.git.clone(
            url,
            path.join(
                (this.app.vault.adapter as FileSystemAdapter).getBasePath(),
                dir
            ),
            depth ? ["--depth", `${depth}`] : []
        );

        // Set required attributes like `absoluteRepoPath` and add the script to the exclude file if needed.
        await this.setGitInstance();
    }

    async setConfig(path: string, value: string | undefined): Promise<void> {
        if (value == undefined) {
            if ((await this.getConfig(path, "local")) !== undefined) {
                await this.git.raw(["config", "--local", "--unset-all", path]);
            }
        } else {
            await this.git.addConfig(path, value, false, "local");
        }
    }

    async getConfig(
        path: string,
        scope: "local" | "global" | "all" = "local"
    ): Promise<string | undefined> {
        const res = await this.git.getConfig(
            path.toLowerCase(),
            scope == "all" ? undefined : scope
        );
        return res.value ?? undefined;
    }

    async fetch(remote?: string): Promise<void> {
        return this.withGitOperation(GitOperation.fetch, async () => {
            await this.git.fetch(remote != undefined ? [remote] : []);
        });
    }

    async setRemote(name: string, url: string): Promise<void> {
        if ((await this.getRemotes()).includes(name))
            await this.git.remote(["set-url", name, url]);
        else {
            await this.git.remote(["add", name, url]);
        }
    }

    async getRemoteBranches(remote: string): Promise<string[]> {
        const res = await this.git.branch(["-r", "--list", `${remote}*`]);

        const list = [];
        for (const item in res.branches) {
            list.push(res.branches[item]!.name);
        }
        return list;
    }

    async getRemotes() {
        const res = await this.git.remote([]);
        if (res) {
            return res.trim().split("\n");
        } else {
            return [];
        }
    }

    async removeRemote(remoteName: string) {
        await this.git.removeRemote(remoteName);
    }

    /**
     * @param remoteBranch - The remote branch to set as upstream, in the format "remote/branch"
     */
    async updateUpstreamBranch(remoteBranch: string) {
        const [remote, branch] = splitRemoteBranch(remoteBranch);
        const current = await this.getCurrentBranch();
        if (!current || !(await this.getRemotes()).includes(remote)) {
            throw this.safetyError("branch --set-upstream-to");
        }
        await this.git.raw(["check-ref-format", `refs/heads/${branch}`]);
        await this.setConfig(`branch.${current}.remote`, remote);
        await this.setConfig(`branch.${current}.merge`, `refs/heads/${branch}`);
    }

    updateGitPath(_: string): Promise<void> {
        return this.setGitInstance();
    }

    updateBasePath(_: string): Promise<void> {
        return this.setGitInstance(true);
    }

    async getDiffString(
        filePath: string,
        stagedChanges = false,
        hash?: string
    ): Promise<string> {
        if (stagedChanges)
            return await this.git.diff(["--cached", "--", filePath]);
        if (hash) return await this.git.show([`${hash}`, "--", filePath]);
        else return await this.git.diff(["--", filePath]);
    }

    async diff(
        file: string,
        commit1: string,
        commit2: string
    ): Promise<string> {
        return await this.git.diff([`${commit1}..${commit2}`, "--", file]);
    }

    async rawCommand(command: string): Promise<string> {
        const parts = command.trim().split(/\s+/);
        const firstPart = parts[0];
        if (firstPart === undefined) return "";
        // 不执行别名、全局选项或任意写操作，避免绕过安全推送入口。
        if (
            ![
                "status",
                "log",
                "diff",
                "show",
                "rev-parse",
                "rev-list",
                "ls-files",
                "ls-tree",
                "ls-remote",
                "merge-base",
                "check-ref-format",
            ].includes(firstPart)
        ) {
            throw this.safetyError("raw-command");
        }
        const res = await this.git.raw(firstPart, ...parts.slice(1));
        return res;
    }

    async getSubmoduleOfFile(
        repositoryRelativeFile: string
    ): Promise<{ submodule: string; relativeFilepath: string } | undefined> {
        // Documentation: https://git-scm.com/docs/git-rev-parse

        if (
            !(await this.app.vault.adapter.exists(
                path.dirname(repositoryRelativeFile)
            ))
        ) {
            return undefined;
        }

        // git -C <dir-of-file> rev-parse --show-toplevel
        // returns the submodules repository root as an absolute path
        let submoduleRoot = await this.git.raw(
            [
                "-C",
                path.dirname(repositoryRelativeFile),
                "rev-parse",
                "--show-toplevel",
            ],
            (err) => err && console.warn("get-submodule-of-file", err?.message)
        );
        submoduleRoot = submoduleRoot.trim();

        // git -C <dir-of-file> rev-parse --show-superproject-working-tree
        // returns the parent git repository, if the file is in a submodule - otherwise empty.
        const superProject = await this.git.raw(
            [
                "-C",
                path.dirname(repositoryRelativeFile),
                "rev-parse",
                "--show-superproject-working-tree",
            ],
            (err) => err && console.warn("get-submodule-of-file", err?.message)
        );

        if (superProject.trim() === "") {
            return undefined; // not in submodule
        }

        const fsAdapter = this.app.vault.adapter as FileSystemAdapter;
        const absolutePath = fsAdapter.getFullPath(
            path.normalize(repositoryRelativeFile)
        );
        const newRelativePath = path.relative(submoduleRoot, absolutePath);

        return { submodule: submoduleRoot, relativeFilepath: newRelativePath };
    }

    async getLastCommitTime(): Promise<Date | undefined> {
        try {
            const res = await this.git.log({ n: 1 });
            if (res != null && res.latest != null) {
                return new Date(res.latest.date);
            }
        } catch (error) {
            if (error instanceof GitError) {
                if (error.message.contains("does not have any commits yet")) {
                    return undefined;
                }
            } else {
                throw error;
            }
        }
        return undefined;
    }

    private async isGitInstalled(): Promise<boolean> {
        // https://github.com/steveukx/git-js/issues/402
        const gitPath = this.plugin.localStorage.getGitPath();
        const command = await spawnAsync(gitPath || "git", ["--version"], {});

        if (command.error) {
            if (Platform.isWin && !gitPath) {
                this.plugin.log(
                    `Git not found in PATH. Checking standard installation path(${DEFAULT_WIN_GIT_PATH}) of Git for Windows.`
                );
                const command = await spawnAsync(DEFAULT_WIN_GIT_PATH, [
                    "--version",
                ]);
                if (command.error) {
                    console.error(command.error);
                    return false;
                } else {
                    this.useDefaultWindowsGitPath = true;
                }
            } else {
                console.error(command.error);
                return false;
            }
        } else {
            this.useDefaultWindowsGitPath = false;
        }
        return true;
    }

    private convertErrors(error: unknown): never {
        if (error instanceof GitError) {
            const message = String(error.message);
            const networkFailure =
                message.contains("Could not resolve host") ||
                message.contains("Unable to resolve host") ||
                message.contains("Unable to open connection") ||
                message.match(
                    /ssh: connect to host .*? port .*?: Operation timed out/
                ) != null ||
                message.match(
                    /ssh: connect to host .*? port .*?: Network is unreachable/
                ) != null ||
                message.match(
                    /ssh: connect to host .*? port .*?: Undefined error: 0/
                ) != null;
            if (networkFailure) {
                throw new NoNetworkError(redactCredentials(message));
            }
        }
        if (error instanceof GitConflictError) {
            throw error;
        }
        throw this.redactError(error);
    }

    private redactError(error: unknown): unknown {
        if (error instanceof Error) {
            // 不透传 GitError 的 task/cause，避免统一日志打印原始凭据。
            const safeError = new Error(redactCredentials(error.message));
            safeError.name = error.name;
            if (error.stack) {
                safeError.stack = redactCredentials(error.stack);
            }
            return safeError;
        }
        return redactCredentials(String(error));
    }

    async isFileTrackedByLFS(filePath: string): Promise<boolean> {
        try {
            // Checks if Gits filter attribute is set to lfs for the file, which means it is (or will be) tracked by LFS.
            const result = await this.git.raw([
                "check-attr",
                "filter",
                filePath,
            ]);
            return result.includes("filter: lfs");
        } catch (error) {
            const errorMessage =
                error instanceof Error ? error.message : String(error);
            // eslint-disable-next-line preserve-caught-error -- Error.cause is unavailable with the project's ES2021 target.
            throw new Error(`Error checking LFS status: ${errorMessage}`);
        }
    }
}

export const zeroCommit: BlameCommit = {
    hash: "000000",
    isZeroCommit: true,
    summary: "",
};

// Parse git blame porcelain format: https://git-scm.com/docs/git-blame#_the_porcelain_format
function parseBlame(blameOutputUnnormalized: string): Blame {
    const blameOutput = blameOutputUnnormalized.replaceAll("\r\n", "\n");

    const blameLines = blameOutput.split("\n");

    const result: Blame = {
        commits: new Map(),
        hashPerLine: [undefined!], // one-based indices
        originalFileLineNrPerLine: [undefined!],
        finalFileLineNrPerLine: [undefined!],
        groupSizePerStartingLine: new Map(),
    };

    let line = 1;
    for (let bi = 0; bi < blameLines.length;) {
        const blameLine = blameLines[bi];
        if (startsWithNonWhitespace(blameLine)) {
            const lineInfo = blameLine.split(" ");

            const commitHash = parseLineInfoInto(lineInfo, line, result);
            bi++;

            // parse header values until a tab is encountered
            for (; startsWithNonWhitespace(blameLines[bi]); bi++) {
                const spaceSeparatedHeaderValues = blameLines[bi]!.split(" ");
                parseHeaderInto(spaceSeparatedHeaderValues, result, line);
            }
            finalizeBlameCommitInfo(result.commits.get(commitHash)!);

            // skip tab prefixed line
            line += 1;
        } else if (blameLine === "" && bi === blameLines.length - 1) {
            // EOF
        } else {
            throw Error(
                `Expected non-whitespace line or EOF, but found: ${blameLine}`
            );
        }
        bi++;
    }
    return result;
}

function parseLineInfoInto(lineInfo: string[], line: number, result: Blame) {
    const hash = lineInfo[0];
    const originalLine = lineInfo[1];
    const finalLine = lineInfo[2];
    if (
        hash === undefined ||
        originalLine === undefined ||
        finalLine === undefined
    ) {
        throw Error(`Invalid git-blame line info: ${lineInfo.join(" ")}`);
    }
    result.hashPerLine.push(hash);
    result.originalFileLineNrPerLine.push(parseInt(originalLine));
    result.finalFileLineNrPerLine.push(parseInt(finalLine));
    if (lineInfo.length >= 4)
        result.groupSizePerStartingLine.set(line, parseInt(lineInfo[3]!));

    if (parseInt(finalLine) !== line) {
        throw Error(
            `git-blame output is out of order: ${line} vs ${finalLine}`
        );
    }

    return hash;
}

function parseHeaderInto(header: string[], out: Blame, line: number) {
    const key = header[0];
    const value = header.slice(1).join(" ");
    const commitHash = out.hashPerLine[line];
    if (commitHash === undefined) {
        throw Error(`No commit hash found for git-blame line ${line}`);
    }
    const commit =
        out.commits.get(commitHash) ||
        <BlameCommit>{
            hash: commitHash,
            author: {},
            committer: {},
            previous: {},
        };

    switch (key) {
        case "summary":
            commit.summary = value;
            break;

        case "author":
            commit.author!.name = value;
            break;
        case "author-mail":
            commit.author!.email = removeEmailBrackets(value);
            break;
        case "author-time":
            commit.author!.epochSeconds = parseInt(value);
            break;
        case "author-tz":
            commit.author!.tz = value;
            break;

        case "committer":
            commit.committer!.name = value;
            break;
        case "committer-mail":
            commit.committer!.email = removeEmailBrackets(value);
            break;
        case "committer-time":
            commit.committer!.epochSeconds = parseInt(value);
            break;
        case "committer-tz":
            commit.committer!.tz = value;
            break;

        case "previous":
            commit.previous!.commitHash = value;
            break;
        case "filename":
            commit.previous!.filename = value;
            break;
        case undefined:
            break;
    }
    out.commits.set(commitHash, commit);
}

function finalizeBlameCommitInfo(commit: BlameCommit) {
    if (commit.summary === undefined) {
        throw Error(`Summary not provided for commit: ${commit.hash}`);
    }

    if (isUndefinedOrEmptyObject(commit.author)) {
        commit.author = undefined;
    }
    if (isUndefinedOrEmptyObject(commit.committer)) {
        commit.committer = undefined;
    }
    if (isUndefinedOrEmptyObject(commit.previous)) {
        commit.previous = undefined;
    }

    commit.isZeroCommit = Boolean(commit.hash.match(/^0*$/));
}

function isUndefinedOrEmptyObject(obj: object | undefined | null): boolean {
    return !obj || Object.keys(obj).length === 0;
}

function startsWithNonWhitespace(str: string | undefined): str is string {
    if (str === undefined) return false;
    return str.length > 0 && str[0]!.trim() === str[0];
}

function removeEmailBrackets(gitEmail: string) {
    const prefixCleaned = gitEmail.startsWith("<")
        ? gitEmail.substring(1)
        : gitEmail;
    return prefixCleaned.endsWith(">")
        ? prefixCleaned.substring(0, prefixCleaned.length - 1)
        : prefixCleaned;
}
