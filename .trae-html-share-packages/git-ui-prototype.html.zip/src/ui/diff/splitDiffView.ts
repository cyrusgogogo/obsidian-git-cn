import type { Debouncer, ViewStateResult, WorkspaceLeaf } from "obsidian";
import { debounce, ItemView, Platform, setIcon } from "obsidian";
import { DEFAULT_SETTINGS, SPLIT_DIFF_VIEW_CONFIG } from "src/constants";
import { SimpleGit } from "src/gitManager/simpleGit";
import { t } from "src/i18n";
import type ObsidianGit from "src/main";
import type { DiffViewState } from "src/types";

import { history, indentWithTab, standardKeymap } from "@codemirror/commands";
import { getChunks, MergeView } from "@codemirror/merge";
import { highlightSelectionMatches, search } from "@codemirror/search";
import { EditorState, Transaction } from "@codemirror/state";
import {
    drawSelection,
    EditorView,
    keymap,
    lineNumbers,
    ViewPlugin,
} from "@codemirror/view";
import { GitError } from "simple-git";
import { Hunks } from "src/editor/signs/hunks";
import { rawHunkFromChunk, rawHunksToHunks } from "src/editor/signs/diff";
import { diffContextMenu } from "src/ui/diff/contextMenu";

const readOnlyEditorTheme = EditorView.theme({
    "& .cm-content": { caretColor: "transparent !important" },
    "&.cm-focused .cm-cursor, & .cm-dropCursor": {
        display: "none !important",
    },
});

const READ_ONLY_DIFF_TIMEOUT_FACTOR = 10;

interface SaveTarget {
    vaultPath: string;
    savedContent: string;
}

interface PendingSave {
    target: SaveTarget;
    content: string;
}

export function getSplitDiffTimeout(
    configuredTimeout: number,
    editable: boolean
): number {
    const timeout =
        Number.isInteger(configuredTimeout) && configuredTimeout > 0
            ? configuredTimeout
            : DEFAULT_SETTINGS.diffTimeout;
    return editable ? timeout : timeout * READ_ONLY_DIFF_TIMEOUT_FACTOR;
}

// This class is not extending `FileView', because it needs a `TFile`, which is not possible for dot files like `.gitignore`, which this editor should support as well.`
export default class SplitDiffView extends ItemView {
    refreshing = false;
    state!: DiffViewState;
    intervalRef: number;
    mergeView: MergeView | undefined;
    fileSaveDebouncer!: Debouncer<[], void>;
    bIsEditable!: boolean;
    private indexUnmerged = false;
    private pendingSave?: PendingSave;
    private savePromise?: Promise<void>;
    private workingTreeSaveTarget?: SaveTarget;
    private editRevision = 0;
    private closed = false;

    /**
     * Prevent to load text from file if the modification event was caused by this instance
     */
    ignoreNextModification = false;

    constructor(
        leaf: WorkspaceLeaf,
        private plugin: ObsidianGit
    ) {
        super(leaf);
        this.navigation = true;
        this.registerEvent(
            this.app.workspace.on("obsidian-git:status-changed", () => {
                if (!this.mergeView || this.indexUnmerged) {
                    this.createMergeView().catch(console.error);
                } else {
                    this.updateRefEditors().catch(console.error);
                }
            })
        );
        this.intervalRef = window.setInterval(() => {
            if (this.mergeView) {
                this.updateRefEditors().catch(console.error);
            }
        }, 30 * 1000);

        this.registerEvent(
            this.app.vault.on("modify", (file) => {
                if (this.isWorkingTreeBFile(file.path)) {
                    if (this.ignoreNextModification) {
                        this.ignoreNextModification = false;
                    } else {
                        this.updateModifiableEditor().catch(console.error);
                    }
                }
            })
        );
        this.registerEvent(
            this.app.vault.on("delete", (file) => {
                if (this.isWorkingTreeBFile(file.path)) {
                    // If the file got deleted, we need to recreate the view to make the editor read-only
                    this.createMergeView().catch(console.error);
                }
            })
        );
        this.registerEvent(
            this.app.vault.on("create", (file) => {
                if (this.isWorkingTreeBFile(file.path)) {
                    // If the file got created, we need to recreate the view to make the editor editable
                    this.createMergeView().catch(console.error);
                }
            })
        );
        this.registerEvent(
            this.app.vault.on("rename", (file, oldPath) => {
                if (
                    this.isWorkingTreeBFile(file.path) ||
                    this.isWorkingTreeBFile(oldPath)
                ) {
                    // If the file got created, we need to recreate the view to make the editor editable
                    this.createMergeView().catch(console.error);
                }
            })
        );

        this.fileSaveDebouncer = debounce(
            () => {
                void this.flushPendingSave().catch((error) =>
                    this.plugin.displayError(error)
                );
            },
            1000,
            false
        );
    }

    scheduleFileSave(target: SaveTarget, content: string): void {
        this.editRevision++;
        this.pendingSave = { target, content };
        this.fileSaveDebouncer();
    }

    async flushPendingSave(): Promise<void> {
        if (this.savePromise) {
            await this.savePromise;
            return this.flushPendingSave();
        }
        const pending = this.pendingSave;
        if (!pending) return;
        this.fileSaveDebouncer?.cancel();
        this.savePromise = new Promise<void>((resolve, reject) => {
            this.plugin.promiseQueue.addTask(async () => {
                try {
                    const { target, content } = pending;
                    if (
                        !target.vaultPath ||
                        target.vaultPath.startsWith("/") ||
                        target.vaultPath.startsWith("\\") ||
                        /^[A-Za-z]:/.test(target.vaultPath) ||
                        target.vaultPath.split(/[\\/]/).includes("..")
                    ) {
                        throw new Error(
                            t("Cannot edit a file outside the vault.")
                        );
                    }
                    const adapter = this.app.vault.adapter;
                    // 队列内校验磁盘基线，禁止覆盖同步或外部编辑的新内容。
                    const current = await adapter.read(target.vaultPath);
                    if (current !== target.savedContent) {
                        throw new Error(
                            t(
                                "The file changed outside the diff editor. Save was blocked; copy your unsaved edits before reloading."
                            )
                        );
                    }
                    this.ignoreNextModification = this.isWorkingTreeBFile(
                        target.vaultPath
                    );
                    try {
                        await adapter.write(target.vaultPath, content);
                    } finally {
                        this.ignoreNextModification = false;
                    }
                    target.savedContent = content;
                    if (this.pendingSave === pending) {
                        this.pendingSave = undefined;
                    }
                    resolve();
                } catch (error) {
                    reject(
                        error instanceof Error
                            ? error
                            : new Error(
                                  t("Could not save the diff editor changes.")
                              )
                    );
                }
            });
        });
        try {
            await this.savePromise;
        } finally {
            this.savePromise = undefined;
        }
        await this.flushPendingSave();
    }

    /**
     * Whether the given vault path is the working tree file shown on the b
     * side. `bFile` is relative to the repository, which may differ from the
     * vault root.
     */
    isWorkingTreeBFile(vaultPath: string): boolean {
        if (
            this.state?.bFile == undefined ||
            this.state.bRef != undefined ||
            !this.plugin.gitManager
        ) {
            return false;
        }
        return (
            vaultPath ===
            this.plugin.gitManager.getRelativeVaultPath(this.state.bFile)
        );
    }

    getViewType(): string {
        return SPLIT_DIFF_VIEW_CONFIG.type;
    }

    getDisplayText(): string {
        if (this.state?.bFile != null) {
            let fileName = this.state.bFile.split("/").last();
            if (fileName?.endsWith(".md")) fileName = fileName.slice(0, -3);
            let suffix: string;
            if (this.state.bRef == undefined) {
                suffix = t("Working Tree");
            } else if (this.state.bRef == "") {
                suffix = t("Index");
            } else {
                suffix = this.state.bRef.substring(0, 7);
            }

            return t("Diff: {file} ({ref})", {
                file: fileName ?? this.state.bFile,
                ref: suffix,
            });
        }
        return t(SPLIT_DIFF_VIEW_CONFIG.name);
    }

    getIcon(): string {
        return SPLIT_DIFF_VIEW_CONFIG.icon;
    }

    async setState(state: DiffViewState, _: ViewStateResult): Promise<void> {
        await this.flushPendingSave();
        this.state = state;

        if (Platform.isMobile) {
            //Update view title on mobile only to show the file name of the diff
            this.leaf.view.titleEl.textContent = this.getDisplayText();
        }
        await super.setState(state, _);

        await this.createMergeView();
    }

    getState(): Record<string, unknown> {
        return this.state;
    }

    async onClose(): Promise<void> {
        await this.flushPendingSave();
        this.closed = true;
        this.fileSaveDebouncer.cancel();
        window.clearInterval(this.intervalRef);
        this.mergeView?.destroy();
        this.mergeView = undefined;
        return super.onClose();
    }

    async onOpen(): Promise<void> {
        this.closed = false;
        await this.createMergeView();
        return super.onOpen();
    }

    async gitShow(commitHash: string, file: string): Promise<string> {
        try {
            return await (this.plugin.gitManager as SimpleGit).show(
                commitHash,
                file,
                false
            );
        } catch (error) {
            if (error instanceof GitError) {
                if (
                    commitHash === "" &&
                    error.message.includes(
                        "is in the index, but not at stage 0"
                    )
                ) {
                    this.indexUnmerged = true;
                    // An unmerged file has no stage 0 entry. Compare with our
                    // side, or an empty file if our side deleted it.
                    try {
                        return await this.plugin.gitManager.show(
                            ":2",
                            file,
                            false
                        );
                    } catch (stageError) {
                        if (
                            stageError instanceof GitError &&
                            stageError.message.includes(
                                "is in the index, but not at stage 2"
                            )
                        ) {
                            return "";
                        }
                        throw stageError;
                    }
                }
                if (
                    error.message.includes("does not exist") ||
                    error.message.includes("unknown revision or path") ||
                    error.message.includes("exists on disk, but not in") ||
                    error.message.includes("fatal: bad object")
                ) {
                    // Occurs when trying to run diff with an object that's actually a nested respository
                    if (error.message.includes("fatal: bad object")) {
                        this.plugin.displayError(error.message);
                    }
                    // If the file does not exist in the commit, return an empty string
                    return "";
                }
            }
            throw error;
        }
    }

    async bShouldBeEditable(state = this.state): Promise<boolean> {
        if (state.bRef != undefined) {
            return false;
        }
        const bVaultPath = this.plugin.gitManager.getRelativeVaultPath(
            state.bFile
        );
        return await this.app.vault.adapter.exists(bVaultPath);
    }

    async updateModifiableEditor() {
        if (!this.mergeView || this.refreshing) return;
        // 未保存的编辑不能被外部刷新替换；保存时会检查磁盘是否已变化。
        if (this.pendingSave) return;
        const bEditor = this.mergeView.b;
        const state = this.state;
        const revision = this.editRevision;

        this.refreshing = true;
        try {
            const newContent = await this.app.vault.adapter.read(
                this.plugin.gitManager.getRelativeVaultPath(state.bFile)
            );
            if (
                this.state !== state ||
                this.mergeView?.b !== bEditor ||
                this.editRevision !== revision ||
                this.pendingSave
            ) {
                return;
            }
            if (newContent != bEditor.state.doc.toString()) {
                if (this.workingTreeSaveTarget) {
                    this.workingTreeSaveTarget.savedContent = newContent;
                }
                const transaction = bEditor.state.update({
                    changes: {
                        from: 0,
                        to: bEditor.state.doc.length,
                        insert: newContent,
                    },
                    // 标记外部刷新，避免将磁盘内容再次写回。
                    annotations: [Transaction.remote.of(true)],
                });
                bEditor.dispatch(transaction);
            }
        } finally {
            this.refreshing = false;
            if (!this.closed && this.state !== state) {
                await this.createMergeView();
            }
        }
    }

    /**
     * Only update the editors which show a file state of some git ref ike HEAD or index and not the current working tree.
     * So only the non editable editors.
     */
    async updateRefEditors() {
        if (!this.mergeView || this.refreshing) return;
        const aEditor = this.mergeView.a;
        const bEditor = this.mergeView.b;
        const state = this.state;

        this.refreshing = true;
        try {
            const aText = await this.gitShow(state.aRef, state.aFile);

            let bText: string | undefined;
            if (state.bRef != undefined) {
                bText = await this.gitShow(state.bRef, state.bFile);
            }
            if (this.state !== state || this.mergeView?.a !== aEditor) return;
            if (this.indexUnmerged) {
                this.refreshing = false;
                await this.createMergeView();
                return;
            }
            if (aText != aEditor.state.doc.toString()) {
                const aTransaction = aEditor.state.update({
                    changes: {
                        from: 0,
                        to: aEditor.state.doc.length,
                        insert: aText,
                    },
                });
                aEditor.dispatch(aTransaction);
            }

            if (bText != undefined && bText != bEditor.state.doc.toString()) {
                const bTransaction = bEditor.state.update({
                    changes: {
                        from: 0,
                        to: bEditor.state.doc.length,
                        insert: bText,
                    },
                });
                bEditor.dispatch(bTransaction);
            }
        } finally {
            this.refreshing = false;
            if (!this.closed && this.state !== state) {
                await this.createMergeView();
            }
        }
    }

    renderButtons(container: Element): HTMLElement {
        const contentEl = container.createDiv();

        const stageButton = contentEl.createDiv();
        stageButton.addClass("clickable-icon");
        stageButton.setAttr(
            "aria-label",
            this.state.bRef == undefined ? t("Stage hunk") : t("Unstage hunk")
        );
        setIcon(stageButton, this.state.bRef == undefined ? "plus" : "minus");

        stageButton.onmousedown = async (_) => {
            const bEditor = this.mergeView!.b;
            const aEditor = this.mergeView!.a;
            const chunks = getChunks(bEditor.state)!;
            const index = contentEl.parentElement?.indexOf(contentEl);

            const chunk = chunks.chunks[index!]!;

            const rawHunk = rawHunkFromChunk(
                chunk,
                aEditor.state.doc,
                bEditor.state.doc
            );
            const hunk = rawHunksToHunks(
                this.mergeView!.a.state.doc.toString(),
                this.mergeView!.b.state.doc.toString(),
                [rawHunk]
            )[0]!;

            const patch =
                Hunks.createPatch(
                    this.state.bFile,
                    [hunk],
                    "100644",
                    this.state.bRef != undefined
                ).join("\n") + "\n";
            await (this.plugin.gitManager as SimpleGit).applyPatch(patch);

            this.plugin.app.workspace.trigger("obsidian-git:refresh");
        };

        if (this.state.bRef == undefined) {
            const resetButton = contentEl.createDiv();
            resetButton.addClass("clickable-icon");
            resetButton.setAttr("aria-label", t("Reset hunk"));
            setIcon(resetButton, "undo");
            resetButton.onmousedown = (_) => {
                const source = this.mergeView!.a;
                const dest = this.mergeView!.b;
                const chunks = getChunks(dest.state)!;
                const index = contentEl.parentElement?.indexOf(contentEl);

                const chunk = chunks.chunks[index!];

                if (chunk) {
                    const srcFrom = chunk.fromA;
                    const srcTo = chunk.toA;
                    const destFrom = chunk.fromB;
                    const destTo = chunk.toB;
                    let insert = source.state.sliceDoc(
                        srcFrom,
                        Math.max(srcFrom, srcTo - 1)
                    );
                    if (srcFrom != srcTo && destTo <= dest.state.doc.length)
                        insert += source.state.lineBreak;
                    dest.dispatch({
                        changes: {
                            from: destFrom,
                            to: Math.min(dest.state.doc.length, destTo),
                            insert,
                        },
                        userEvent: "revert",
                    });
                }
            };
        }

        // Prevent the default revert behavior by codemirror to apply
        contentEl.onmousedown = (event) => {
            event.preventDefault();
            event.stopPropagation();
        };
        return contentEl;
    }

    async createMergeView() {
        await this.flushPendingSave();
        const state = this.state;
        if (
            state?.aFile &&
            state?.bFile &&
            !this.closed &&
            !this.refreshing &&
            this.plugin.gitManager
        ) {
            const revision = this.editRevision;
            const vaultPath = this.plugin.gitManager.getRelativeVaultPath(
                state.bFile
            );
            this.refreshing = true;
            try {
                const editable = await this.bShouldBeEditable(state);
                this.indexUnmerged = false;

                const aText = await this.gitShow(state.aRef, state.aFile);

                let bText: string;
                if (state.bRef != undefined) {
                    bText = await this.gitShow(state.bRef, state.bFile);
                } else {
                    if (await this.app.vault.adapter.exists(vaultPath)) {
                        bText = await this.app.vault.adapter.read(vaultPath);
                    } else {
                        bText = "";
                    }
                }

                // 读取期间可能切换视图或继续编辑，不能用旧快照销毁当前编辑器。
                if (
                    this.closed ||
                    this.state !== state ||
                    this.editRevision !== revision ||
                    this.pendingSave
                ) {
                    return;
                }
                if (
                    editable &&
                    (!vaultPath ||
                        vaultPath.startsWith("/") ||
                        vaultPath.startsWith("\\") ||
                        /^[A-Za-z]:/.test(vaultPath) ||
                        vaultPath.split(/[\\/]/).includes(".."))
                ) {
                    throw new Error(t("Cannot edit a file outside the vault."));
                }

                this.bIsEditable = editable;
                this.mergeView?.destroy();
                const container = this.containerEl.children[1]!;
                container.empty();
                this.contentEl.addClass("git-split-diff-view", "git-diff");

                const basicExtensions = [
                    lineNumbers(),
                    highlightSelectionMatches(),
                    drawSelection(),
                    keymap.of([...standardKeymap, indentWithTab]),
                    history(),
                    search(),
                    EditorView.lineWrapping,
                    diffContextMenu,
                ];
                const saveTarget: SaveTarget = {
                    vaultPath,
                    savedContent: bText,
                };
                this.workingTreeSaveTarget = editable ? saveTarget : undefined;
                const autoSavePlugin = ViewPlugin.define((view) => ({
                    update: (update) => {
                        if (
                            update.docChanged &&
                            !update.transactions.some((tr) =>
                                tr.annotation(Transaction.remote)
                            )
                        ) {
                            this.scheduleFileSave(
                                saveTarget,
                                view.state.doc.toString()
                            );
                        }
                    },
                }));

                const aState = {
                    doc: aText,
                    extensions: [
                        ...basicExtensions,
                        EditorState.readOnly.of(true),
                        readOnlyEditorTheme,
                    ],
                };

                const bExtensions = [...basicExtensions];

                // 仅工作区文件允许编辑和自动保存。
                if (!editable) {
                    bExtensions.push(
                        EditorState.readOnly.of(true),
                        readOnlyEditorTheme
                    );
                } else {
                    bExtensions.push(autoSavePlugin);
                }

                const bState = {
                    doc: bText,
                    extensions: bExtensions,
                };

                container.addClasses([
                    "cm-s-obsidian",
                    "mod-cm6",
                    "markdown-source-view",
                    "cm-content",
                ]);

                const showButtons =
                    this.plugin.gitManager instanceof SimpleGit &&
                    !this.indexUnmerged &&
                    (state.bRef === undefined || state.bRef === "");

                this.mergeView = new MergeView({
                    b: bState,
                    a: aState,
                    collapseUnchanged: {
                        minSize: 6,
                        margin: 4,
                    },
                    renderRevertControl: showButtons
                        ? () => this.renderButtons(container)
                        : undefined,
                    revertControls: showButtons ? "a-to-b" : undefined,
                    diffConfig: {
                        timeout: getSplitDiffTimeout(
                            this.plugin.settings.diffTimeout,
                            editable
                        ),
                    },
                    parent: container,
                });
            } finally {
                this.refreshing = false;
                if (!this.closed && this.state !== state) {
                    await this.createMergeView();
                }
            }
        }
    }
}
