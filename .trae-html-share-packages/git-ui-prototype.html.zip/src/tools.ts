import { Platform, TFile } from "obsidian";
import {
    DIFF_VIEW_CONFIG,
    READ_ONLY_FILE_VIEW_CONFIG,
    SPLIT_DIFF_VIEW_CONFIG,
} from "./constants";
import type ObsidianGit from "./main";
import { SimpleGit } from "./gitManager/simpleGit";
import { getNewLeaf, splitRemoteBranch } from "./utils";
import { GeneralModal } from "./ui/modals/generalModal";
import { t } from "./i18n";
import type { DiffViewState, ReadOnlyFileViewState } from "./types";

export default class Tools {
    constructor(private readonly plugin: ObsidianGit) {}

    async hasTooBigFiles(
        files: { vaultPath: string; path: string }[]
    ): Promise<boolean> {
        const branchInfo = await this.plugin.gitManager.branchInfo();
        const remote = branchInfo.tracking
            ? splitRemoteBranch(branchInfo.tracking)[0]
            : null;

        if (!remote) return false;

        const remoteUrl = await this.plugin.gitManager.getRemoteUrl(remote);

        //Check for files >100mb on GitHub remote
        if (remoteUrl?.includes("github.com")) {
            const tooBigFiles = [];

            const gitManager = this.plugin.gitManager;
            for (const f of files) {
                const file = this.plugin.app.vault.getAbstractFileByPath(
                    f.vaultPath
                );
                let over100mb = false;

                if (file instanceof TFile) {
                    // Prefer the cached file size if available
                    if (file.stat.size >= 100000000) {
                        over100mb = true;
                    }
                } else {
                    const statRes = await this.plugin.app.vault.adapter.stat(
                        f.vaultPath
                    );
                    if (statRes && statRes.size >= 100000000) {
                        over100mb = true;
                    }
                }
                if (over100mb) {
                    let isFileTrackedByLfs = false;
                    if (gitManager instanceof SimpleGit) {
                        isFileTrackedByLfs =
                            await gitManager.isFileTrackedByLFS(f.path);
                    }
                    if (!isFileTrackedByLfs) {
                        tooBigFiles.push(f);
                    }
                }
            }

            if (tooBigFiles.length > 0) {
                this.plugin.displayError(
                    t(
                        "Aborted commit, because the following files are too big:\n- {files}\nPlease remove them or add to .gitignore.",
                        {
                            files: tooBigFiles
                                .map((e) => e.vaultPath)
                                .join("\n- "),
                        }
                    )
                );

                return true;
            }
        }
        return false;
    }
    openDiff({
        aFile,
        bFile,
        aRef,
        bRef,
        event,
    }: {
        aFile: string;
        bFile?: string;
        aRef: string;
        bRef?: string;
        event?: MouseEvent;
    }) {
        let diffStyle = this.plugin.settings.diffStyle;
        if (Platform.isMobileApp) {
            diffStyle = "git_unified";
        }

        const state: DiffViewState = {
            aFile: aFile,
            bFile: bFile ?? aFile,
            aRef: aRef,
            bRef: bRef,
        };

        if (diffStyle == "split") {
            void getNewLeaf(this.plugin.app, event)?.setViewState({
                type: SPLIT_DIFF_VIEW_CONFIG.type,
                active: true,
                state: state,
            });
        } else if (diffStyle == "git_unified") {
            void getNewLeaf(this.plugin.app, event)?.setViewState({
                type: DIFF_VIEW_CONFIG.type,
                active: true,
                state: state,
            });
        }
    }

    async openFileAtCommit(file: string, ref: string): Promise<void> {
        const state: ReadOnlyFileViewState = { file, ref };
        await this.plugin.app.workspace.getLeaf("tab").setViewState({
            type: READ_ONLY_FILE_VIEW_CONFIG.type,
            active: true,
            state,
        });
    }

    async runRawCommand() {
        if (!(this.plugin.gitManager instanceof SimpleGit)) {
            return;
        }
        const modal = new GeneralModal(this.plugin, {
            placeholder: "push origin master",
            allowEmpty: false,
        });
        const command = await modal.openAndGetResult();
        if (command === undefined) return;

        this.plugin.promiseQueue.addTask(() =>
            this.plugin.gitActions.runRawCommand(command)
        );
    }
}
