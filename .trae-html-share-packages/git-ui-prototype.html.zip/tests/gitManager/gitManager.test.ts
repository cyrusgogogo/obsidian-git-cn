import { afterEach, describe, expect, it, vi } from "vitest";
import { GitActions } from "../../src/gitActions";
import { IsomorphicGit } from "../../src/gitManager/isomorphicGit";
import { t } from "../../src/i18n";
import { GitConflictError, type FileStatusResult } from "../../src/types";
import { createFakePlugin } from "../helpers/createFakePlugin";
import {
    gitManagerBackends,
    type GitManagerTestHarness,
} from "../helpers/gitManagerHarness";
import { createRepoWithMergeConflict } from "../helpers/gitRepo";

function statusByPath(
    files: FileStatusResult[]
): Map<string, FileStatusResult> {
    return new Map(files.map((file) => [file.path, file]));
}

function configureGitActions({
    manager,
    plugin,
}: GitManagerTestHarness): GitActions {
    // 两个后端夹具都会覆盖部分本地状态方法，保留覆盖项并补齐新接口。
    plugin.localStorage = {
        ...createFakePlugin().localStorage,
        ...plugin.localStorage,
    } as unknown as typeof plugin.localStorage;
    plugin.isAllInitialized = vi.fn().mockResolvedValue(true);
    plugin.tools = {
        hasTooBigFiles: vi.fn().mockResolvedValue(false),
    } as unknown as typeof plugin.tools;
    plugin.displayMessage = vi.fn();
    plugin.updateCachedStatus = vi.fn(async () => {
        const status = await manager.status();
        plugin.state.mergeInProgress = await manager.isMergeInProgress();
        return status;
    });
    const actions = new GitActions(plugin);
    plugin.gitActions = actions;
    return actions;
}

describe.each(gitManagerBackends)("$name GitManager contract", (backend) => {
    let context: GitManagerTestHarness | undefined;

    afterEach(() => {
        context?.cleanup();
        context = undefined;
    });

    it("reports repository-relative paths and consistent file states", async () => {
        context = await backend.create();
        const { manager, repo } = context;
        await repo.writeAndCommit(
            "deleted.md",
            "deleted\n",
            "add deleted file"
        );
        repo.write("note.md", "modified\n");
        repo.write("staged.md", "staged\n");
        repo.write("untracked.md", "untracked\n");
        await repo.git.add("staged.md");
        repo.remove("deleted.md");

        const status = await manager.status();
        const files = statusByPath(status.all);
        const basePath = context.plugin.settings.basePath;

        expect([...files.keys()].sort()).toEqual([
            "deleted.md",
            "note.md",
            "staged.md",
            "untracked.md",
        ]);
        expect(files.get("note.md")).toMatchObject({
            path: "note.md",
            vaultPath: `${basePath}/note.md`,
            index: " ",
            workingDir: "M",
        });
        expect(files.get("staged.md")).toMatchObject({
            path: "staged.md",
            vaultPath: `${basePath}/staged.md`,
            index: "A",
            workingDir: " ",
        });
        expect(files.get("untracked.md")).toMatchObject({
            path: "untracked.md",
            vaultPath: `${basePath}/untracked.md`,
            index: "U",
            workingDir: "U",
        });
        expect(files.get("deleted.md")).toMatchObject({
            path: "deleted.md",
            vaultPath: `${basePath}/deleted.md`,
            index: " ",
            workingDir: "D",
        });
        expect(status.changed.map((file) => file.path).sort()).toEqual([
            "deleted.md",
            "note.md",
            "untracked.md",
        ]);
        expect(status.staged.map((file) => file.path)).toEqual(["staged.md"]);
    });

    it("reads a file snapshot from a commit without changing the working tree", async () => {
        context = await backend.create();
        const { manager, plugin, repo } = context;
        const commit = await repo.head();
        repo.write("note.md", "working tree\n");

        await expect(
            manager.show(commit, `${plugin.settings.basePath}/note.md`)
        ).resolves.toBe("base\n");
        await expect(manager.show(commit, "note.md", false)).resolves.toBe(
            "base\n"
        );
        await expect(repo.statusPorcelain()).resolves.toBe("M note.md");
    });

    it("updates status after staging and unstaging a vault-relative path", async () => {
        context = await backend.create();
        const { manager, plugin, repo } = context;
        repo.write("note.md", "changed\n");
        const vaultPath = `${plugin.settings.basePath}/note.md`;

        await manager.stage(vaultPath, true);

        let status = await manager.status();
        expect(status.changed).toEqual([]);
        expect(status.staged).toHaveLength(1);
        expect(status.staged[0]).toMatchObject({
            path: "note.md",
            vaultPath,
            index: "M",
            workingDir: " ",
        });

        await manager.unstage(vaultPath, true);

        status = await manager.status();
        expect(status.staged).toEqual([]);
        expect(status.changed).toHaveLength(1);
        expect(status.changed[0]).toMatchObject({
            path: "note.md",
            vaultPath,
            index: " ",
            workingDir: "M",
        });
    });

    it("commits staged changes without staging unstaged changes", async () => {
        context = await backend.create();
        const { manager, repo } = context;
        repo.write("staged.md", "staged\n");
        repo.write("unstaged.md", "unstaged\n");
        await repo.git.add("staged.md");

        const committedFiles = await manager.commit({
            message: "commit staged",
        });

        expect(committedFiles).toBe(1);
        expect(await repo.headMessage()).toBe("commit staged");
        expect(await repo.show("HEAD:staged.md")).toBe("staged");
        expect(await repo.statusPorcelain()).toBe("?? unstaged.md");
    });

    it("amends the previous commit and returns the committed file count", async () => {
        context = await backend.create();
        const { manager, repo } = context;
        const headBefore = await repo.head();
        repo.write("note.md", "base\namended\n");
        await repo.git.add("note.md");

        const committedFiles = await manager.commit({
            message: "amended base",
            amend: true,
        });

        expect(committedFiles).toBe(1);
        expect(await repo.head()).not.toBe(headBefore);
        expect(await repo.headMessage()).toBe("amended base");
        expect(await repo.unpushedCount()).toBe(1);
        expect(await repo.show("HEAD:note.md")).toBe("base\namended");
        expect(await repo.statusPorcelain()).toBe("");
    });

    it("amends while staging all changes", async () => {
        context = await backend.create();
        const { manager, repo } = context;
        const headBefore = await repo.head();
        repo.write("note.md", "base\namended all\n");

        const committedFiles = await manager.commitAll({
            message: "amended all",
            amend: true,
        });

        expect(committedFiles).toBe(1);
        expect(await repo.head()).not.toBe(headBefore);
        expect(await repo.headMessage()).toBe("amended all");
        expect(await repo.show("HEAD:note.md")).toBe("base\namended all");
        expect(await repo.statusPorcelain()).toBe("");
    });

    it("stages and commits tracked, untracked, and deleted files", async () => {
        context = await backend.create();
        const { manager, repo } = context;
        await repo.writeAndCommit(
            "delete-me.md",
            "delete me\n",
            "add deleted file"
        );
        await repo.git.push(["--quiet"]);
        repo.write("note.md", "base\nchanged\n");
        repo.write("created.md", "created\n");
        repo.remove("delete-me.md");

        const committedFiles = await manager.commitAll({
            message: "commit all",
        });

        expect(committedFiles).toBe(3);
        expect(await repo.headMessage()).toBe("commit all");
        expect(await repo.show("HEAD:note.md")).toBe("base\nchanged");
        expect(await repo.show("HEAD:created.md")).toBe("created");
        expect(await repo.statusPorcelain()).toBe("");
        await expect(repo.show("HEAD:delete-me.md")).rejects.toThrow();
    });

    it("normalizes detached HEAD and handles operations without a current branch", async () => {
        context = await backend.create();
        const { manager, plugin, repo } = context;
        await repo.raw(["checkout", "--quiet", "--detach", "HEAD"]);

        const branchInfo = await manager.branchInfo();

        expect(branchInfo.current).toBeUndefined();
        expect(branchInfo.tracking).toBeUndefined();
        await expect(manager.canPush()).resolves.toBe(false);
        await expect(manager.pull()).rejects.toThrow(
            manager instanceof IsomorphicGit
                ? "No current branch found. Cannot pull."
                : t("No current branch found. Cannot pull.")
        );
        expect(plugin.displayError).not.toHaveBeenCalled();
        await expect(manager.push()).resolves.toEqual({
            status: "blocked",
            reason: "no-branch",
        });
        expect(plugin.displayError).not.toHaveBeenCalled();
    });

    it("normalizes a missing tracking branch and skips pulling", async () => {
        context = await backend.create();
        const { manager, plugin, repo } = context;
        await repo.git.checkoutLocalBranch("local-only");

        const branchInfo = await manager.branchInfo();

        expect(branchInfo.current).toBe("local-only");
        expect(branchInfo.tracking).toBeUndefined();
        await expect(manager.canPush()).resolves.toBe(false);
        await expect(manager.pull()).resolves.toEqual({
            status: "skipped",
            reason: "no-upstream",
        });
        if (manager instanceof IsomorphicGit) {
            expect(plugin.log).toHaveBeenCalledWith(
                "No tracking branch found. Ignoring pull."
            );
        }
        expect(plugin.displayError).not.toHaveBeenCalled();
    });

    it("returns an explicit result when a pull is up to date", async () => {
        context = await backend.create();
        vi.spyOn(context.manager, "fetch").mockResolvedValue();

        await expect(context.manager.pull()).resolves.toEqual({
            status: "up-to-date",
        });
    });

    it("removes a conflict after staging while keeping the merge active", async () => {
        context = await backend.create(createRepoWithMergeConflict);
        const { manager, repo } = context;
        repo.write("untracked.md", "untracked\n");

        const status = await manager.status();
        expect(status.conflicted).toEqual(["note.md"]);
        expect(status.all.map((file) => file.path)).toContain("note.md");
        expect(status.changed.map((file) => file.path)).not.toContain(
            "note.md"
        );
        expect(status.changed).toContainEqual(
            expect.objectContaining({
                path: "untracked.md",
                index: "U",
                workingDir: "U",
            })
        );
        expect(await manager.isMergeInProgress()).toBe(true);

        repo.write("note.md", "resolved\n");
        await manager.stage("note.md", false);

        expect((await manager.status()).conflicted).toEqual([]);
        expect(await manager.isMergeInProgress()).toBe(true);
    });

    it("creates a two-parent merge commit and clears the merge state", async () => {
        context = await backend.create(createRepoWithMergeConflict);
        const { manager, repo } = context;
        repo.write("note.md", "resolved\n");
        await manager.stage("note.md", false);

        const committedFiles = await manager.commit({
            message: "resolve merge",
        });

        const [commit, ...parents] = (
            await repo.raw(["rev-list", "--parents", "-n", "1", "HEAD"])
        ).split(" ");
        expect(commit).toBe(await repo.head());
        expect(parents).toHaveLength(2);
        expect(await repo.headMessage()).toBe("resolve merge");
        expect(await repo.show("HEAD:note.md")).toBe("resolved");
        expect(await manager.isMergeInProgress()).toBe(false);
        expect(committedFiles).toBe(1);
    });

    it("finishes a merge resolved to ours with no staged changes", async () => {
        context = await backend.create(createRepoWithMergeConflict);
        const { manager, repo } = context;
        repo.write("note.md", "ours\n");
        await manager.stage("note.md", false);

        const status = await manager.status();
        expect(status.conflicted).toEqual([]);
        expect(status.staged).toEqual([]);
        expect(status.changed).toEqual([]);
        expect(await manager.isMergeInProgress()).toBe(true);

        const committedFiles = await manager.commit({
            message: "resolve merge",
        });

        expect(committedFiles).toBe(0);
        expect(
            (await repo.raw(["rev-list", "--parents", "-n", "1", "HEAD"]))
                .split(" ")
                .slice(1)
        ).toHaveLength(2);
        expect(await manager.isMergeInProgress()).toBe(false);
    });

    it("commits an empty resolved merge in smart mode without automatic staging", async () => {
        context = await backend.create(createRepoWithMergeConflict);
        const { manager, plugin, repo } = context;
        repo.write("note.md", "ours\n");
        await manager.stage("note.md", false);
        plugin.state.mergeInProgress = true;
        plugin.settings.autoStageOnEmptyIndex = false;
        const actions = configureGitActions(context);

        const result = await actions.commit({
            fromAuto: false,
            commitMessage: "resolve merge",
            mode: "smart",
        });

        expect(result).toEqual({
            status: "success",
            value: { status: "committed", files: 0 },
        });
        expect(await manager.isMergeInProgress()).toBe(false);
    });

    it("commits all changes without extra working tree walks", async () => {
        context = await backend.create();
        const { manager, repo } = context;
        await repo.writeAndCommit("deleted.md", "deleted\n", "add deleted");
        repo.write("note.md", "modified\n");
        repo.write("untracked.md", "untracked\n");
        repo.remove("deleted.md");
        const extraWalks =
            manager instanceof IsomorphicGit
                ? [
                      vi.spyOn(manager, "getUnstagedFiles"),
                      vi.spyOn(manager, "getStagedFiles"),
                  ]
                : [];
        const actions = configureGitActions(context);

        const result = await actions.commit({
            fromAuto: false,
            commitMessage: "commit all",
            mode: "all",
        });

        expect(result).toEqual({
            status: "success",
            value: { status: "committed", files: 3 },
        });
        for (const walk of extraWalks) {
            expect(walk).not.toHaveBeenCalled();
        }
        expect((await manager.status()).all).toEqual([]);
    });

    it("lists staged files in the commit message", async () => {
        context = await backend.create();
        const { manager, plugin, repo } = context;
        await repo.writeAndCommit("deleted.md", "deleted\n", "add deleted");
        repo.write("note.md", "modified\n");
        repo.write("added.md", "added\n");
        repo.write("unstaged.md", "unstaged\n");
        repo.remove("deleted.md");
        await manager.stage("note.md", false);
        await manager.stage("added.md", false);
        await manager.stage("deleted.md", false);
        plugin.settings.listChangedFilesInMessageBody = true;
        const status = vi.spyOn(manager, "status");

        const message = await manager.formatCommitMessage(
            "{{numFiles}} files: {{files}}"
        );

        const [summary, body] = message.split("\n\nAffected files:\n");
        expect(summary).toMatch(/^3 files: /);
        expect(summary).toContain("A added.md");
        expect(summary).toContain("D deleted.md");
        expect(summary).toContain("M note.md");
        expect(body?.split("\n").sort()).toEqual([
            "added.md",
            "deleted.md",
            "note.md",
        ]);
        if (manager instanceof IsomorphicGit) {
            expect(status).not.toHaveBeenCalled();
        }
    });

    it("refreshes conflict status before pushing in commit-and-sync", async () => {
        context = await backend.create();
        const { manager, plugin, repo } = context;
        repo.write("note.md", "modified\n");
        const events: string[] = [];
        plugin.settings.pullBeforePush = true;
        plugin.settings.syncMethod = "merge";
        plugin.settings.disablePush = false;
        const actions = configureGitActions(context);
        plugin.updateCachedStatus = vi.fn(async () => {
            events.push("status");
            const status = await manager.status();
            plugin.state.mergeInProgress = await manager.isMergeInProgress();
            return status;
        });
        vi.spyOn(manager, "pull").mockImplementation(() => {
            events.push("pull");
            return Promise.resolve({ status: "up-to-date" });
        });
        vi.spyOn(manager, "canPush").mockResolvedValue(true);
        vi.spyOn(manager, "push").mockImplementation(() => {
            events.push("push");
            return Promise.resolve({ status: "pushed", files: 1 });
        });

        const result = await actions.commitAndSync({
            fromAutoBackup: false,
            commitMessage: "sync",
        });

        expect(plugin.displayError).not.toHaveBeenCalled();
        expect(result).toMatchObject({
            status: "success",
            value: { status: "synced" },
        });
        // 提交阶段仍复用状态，推送前的安全刷新不能用旧性能断言禁止。
        expect(events.slice(events.indexOf("pull"))).toEqual([
            "pull",
            "status",
            "push",
        ]);
        expect(await repo.headMessage()).toBe("sync");
        expect(await repo.statusPorcelain()).toBe("");
    });

    it("does not push if a conflict appears after pulling in commit-and-sync", async () => {
        context = await backend.create();
        const { manager, plugin, repo } = context;
        repo.write("note.md", "modified\n");
        plugin.settings.pullBeforePush = true;
        plugin.settings.syncMethod = "merge";
        plugin.settings.disablePush = false;
        const actions = configureGitActions(context);
        let pulled = false;
        plugin.updateCachedStatus = vi.fn(async () => {
            const status = await manager.status();
            return pulled ? { ...status, conflicted: ["note.md"] } : status;
        });
        plugin.handleConflict = vi.fn();
        vi.spyOn(manager, "pull").mockImplementation(() => {
            pulled = true;
            return Promise.resolve({ status: "up-to-date" });
        });
        vi.spyOn(manager, "canPush").mockResolvedValue(true);
        const push = vi.spyOn(manager, "push");

        const result = await actions.commitAndSync({
            fromAutoBackup: false,
            commitMessage: "sync",
        });

        expect(result).toMatchObject({
            status: "success",
            value: { status: "skipped", reason: "push-skipped" },
        });
        expect(plugin.handleConflict).toHaveBeenCalledWith(["note.md"]);
        expect(push).not.toHaveBeenCalled();
        expect(await repo.headMessage()).toBe("sync");
    });

    it("counts merge changes when committing all files", async () => {
        context = await backend.create(createRepoWithMergeConflict);
        const { manager, repo } = context;
        repo.write("note.md", "resolved\n");

        const committedFiles = await manager.commitAll({
            message: "resolve merge",
        });

        expect(committedFiles).toBe(1);
        expect(await repo.show("HEAD:note.md")).toBe("resolved");
        expect(await manager.isMergeInProgress()).toBe(false);
    });

    it("normalizes an unmerged-paths commit failure without displaying it", async () => {
        context = await backend.create(createRepoWithMergeConflict);
        const { manager, plugin } = context;

        await expect(
            manager.commit({ message: "still conflicted" })
        ).rejects.toBeInstanceOf(GitConflictError);

        expect(plugin.displayError).not.toHaveBeenCalled();
    });
});
